<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="uploadproductimage.php" method="post"  enctype="multipart/form-data">
		<input type="file" id="productimage" name="productimage" >
		<br>
		<button type="submit">Submit</button>
	</form>
</body>
</html>