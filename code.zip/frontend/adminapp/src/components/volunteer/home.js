import React,{ Component } from "react";
export default class Home extends Component{
 render(){
     return(
         <h2>hello volunteer!</h2>
     )
 }
}